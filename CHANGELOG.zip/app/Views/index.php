<?= $this->extend("template/dashboard"); ?>
<?= $this->section("content") ?>
<p>Selamat Datang di Peduli Diri. Silahkan masukkan catatan perjalanan</p>

<?= $this->endSection() ?>